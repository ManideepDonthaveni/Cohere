.. Cohere Python SDK documentation master file, created by
   sphinx-quickstart on Wed Feb 15 09:42:17 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the Cohere Python SDK documentation!
===============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   cohere.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
